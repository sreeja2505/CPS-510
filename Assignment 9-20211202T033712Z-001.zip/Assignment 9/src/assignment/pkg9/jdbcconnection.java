/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg9;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author sreejachowdary
 */
public class jdbcconnection {
 
    public static void main(String[] args) {
 
        Connection conn1 = null;

        try {
            // registers Oracle JDBC driver - though this is no longer required
            // since JDBC 4.0, but added here for backward compatibility
            Class.forName("oracle.jdbc.OracleDriver");
 
           
         //   String dbURL1 = "jdbc:oracle:thin:username/password@oracle.scs.ryerson.ca:1521:orcl";  // that is school Oracle database and you can only use it in the labs
																						
         String username = "nkurra";
         String password = "05250707";
            
            String dbURL1 = "jdbc:oracle:thin:" + username + "/" + password + "@oracle.cs.ryerson.ca:1521:orcl";
			
			
			conn1 = DriverManager.getConnection(dbURL1);
            if (conn1 != null) {
                System.out.println("Connected with connection #1");
            }
			
                        String query = "select NAME, NUM from TESTJDBC";
							
			try (Statement stmt = conn1.createStatement()) {
                            Scanner in = new Scanner(System.in);
                            char inp;
                            boolean stay = true;
                            System.out.println("1 - Create Tables\n2 - PopulateTables\n3 - Query Tables\n4 - Drop Tables\ne - Exit");
                            while (stay) {
                                System.out.print("=> ");
                                inp = in.next().charAt(0);
                                switch (inp) {
                                    case '1':
                                        createTables(stmt);
                                        break;
                                    case '2':
                                        populateTables(stmt);
                                        break;
                                    case '3':
                                        queryTables(stmt);
                                        break;
                                    case '4':
                                        dropTables(stmt);
                                        break;
                                    case 'e':
                                        stay = false;
                                        System.out.println("Exiting Program");
                                        break;
                                    default:
                                        System.out.println("Invalid Input");
                                        
                                }   
                            }
                            
			} catch (SQLException e) {
				System.out.println("Error " + e.getErrorCode());
                                //e.printStackTrace();
			}


 
        } catch (ClassNotFoundException | SQLException ex) {
        } finally {
            try {
                if (conn1 != null && !conn1.isClosed()) {
                    conn1.close();
                }
     
            } catch (SQLException ex) {
            }
        }
			

    }
    
    public static void createTables(Statement stmt) throws SQLException {
        String[] queries = {/*"CREATE TABLE Nurse_Name_Table (ID varchar(255) REFERENCES Employee_Type_Table(Emp_ID), E_Name varchar(255))",
                            "CREATE TABLE Doctor_Specialty (D_ID varchar(255) REFERENCES Employee_Type_Table(Emp_ID), Ext_Number varchar(255), Specialty varchar(255))",
                            "CREATE TABLE Employee_Login_Details (Emp_ID varchar(255) REFERENCES Employee_Type_Table(Emp_ID), Username varchar(255),Pword varchar(255))",*/
                            //"CREATE TABLE Employee_Personal_Details (Emp_ID varchar(255) REFERENCES Employee_Type_Table(Emp_ID),Gender varchar(255),Address varchar(255))",
                            "CREATE TABLE Clinic_Info( Clinic_ID int ,Clinic_Name varchar(255),Clinic_Address varchar(255),Clinic_Phone_Number varchar(255))"
                            };
        for (String query : queries) {
            stmt.executeUpdate(query);
        }
        System.out.println("Tables Created");
    }
    
    public static void populateTables(Statement stmt) throws SQLException {
        String[] queries = {"INSERT INTO CLINIC_INFO VALUES(1,'West Clinic','1062 West Street, Toronto','7528825732')",
                            "INSERT INTO CLINIC_INFO VALUES(2,'East Clinic','888 East Street, Waterloo','8471920594')",
                            //"INSERT INTO MEDICINE_TABLE VALUES(86, 'Amoxicillin')",
                            //"INSERT INTO MEDICINE_TABLE VALUES(222, 'Cefaclor')",
                            //"INSERT INTO Employee_Type_Table VALUES(1, 'Nurse')",
                            //"INSERT INTO Employee_Login_Details VALUES(1, 'test', 'test')"
                            };
        for (String query : queries) {
            stmt.executeUpdate(query);
        }
        System.out.println("Tables Populated");
    }
    
    public static void queryTables(Statement stmt) throws SQLException {
        String[] queries = {"SELECT * FROM CLINIC_INFO",
                            "SELECT * FROM MEDICAL_RECORD",
                            /*"CREATE VIEW male_employees AS SELECT EMP_ID, EMP_NAME, GENDER FROM EMPLOYEE_PERSONAL_DETAILS WHERE GENDER = 'M'",
                            "CREATE VIEW medicine_with_id_over_100 AS SELECT MED_ID, MED_NAME FROM MEDICINE_TABLE WHERE MED_ID > 100",*/};
        for (String query : queries) {
            System.out.println(query);
            ResultSet rs = stmt.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            ArrayList<String> columns = new ArrayList<>();
            for(int i = 1; i <= rsmd.getColumnCount(); i++) {
                columns.add(rsmd.getColumnName(i));
                System.out.print(rsmd.getColumnName(i));
                if (i != rsmd.getColumnCount())
                    System.out.print(", ");
            }
            System.out.println();
            while (rs.next()) {
                for (String c : columns) {
                    System.out.print(rs.getString(c));
                    if (!columns.get(columns.size() - 1).equals(c))
                        System.out.print(", ");
                }
                System.out.println();
            }
            System.out.println();
        }
        System.out.println("Tables Queried");
    }
    
    public static void dropTables(Statement stmt) throws SQLException {
        String[] queries = {//"DROP TABLE MEDICINE_TABLE"
                            "DROP TABLE CLINIC_INFO"
                            //"DROP TABLE PATIENT_CHECK2"
                           };
        for (String query : queries) {
            stmt.executeUpdate(query);
        }
        System.out.println("Tables Dropped");
    }
    
}
